#!/bin/bash

# 1.构建镜像
export JAVA_HOME=/opt/jdk8
/opt/maven/bin/mvn clean package

# 2.替换变量
cd /root/ansible_kaoshi/
sed -i "/APP_VERSION=/c APP_VERSION=$releaseVersion" kaoshi.env
sed -i "/APP_ENV=/c APP_ENV=${deployEnv,,}" kaoshi.env

# 3.调用Ansible剧本
ansible-playbook -l $deployHosts ansible_kaoshi.yaml -e "app_version=$releaseVersion"
