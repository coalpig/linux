#!/bin/bash

# 项目名称
APP_NAME="xzs"
# 项目版本
APP_VERSION="3.9.0"
# Spring Boot 配置文件
SPRING_PROFILES_ACTIVE="prod"
# JAR 文件路径
JAR_PATH="/opt/${APP_NAME}-${APP_VERSION}.jar"
# Java 选项
JAVA_OPTS="-Duser.timezone=Asia/Shanghai -Dspring.profiles.active=${SPRING_PROFILES_ACTIVE}"

# PID 文件路径
PID_FILE="/var/run/${APP_NAME}.pid"

start() {
  if [ -f "$PID_FILE" ]; then
    echo "Application is already running."
  else
    echo "Starting application..."
    nohup java $JAVA_OPTS -jar $JAR_PATH > /dev/null 2>&1 &
    echo $! > $PID_FILE
    echo "Application started."
  fi
}

stop() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat $PID_FILE)
    echo "Stopping application..."
    kill $PID
    rm -f $PID_FILE
    echo "Application stopped."
  else
    echo "Application is not running."
  fi
}

restart() {
  stop
  start
}

status() {
  if [ -f "$PID_FILE" ]; then
    PID=$(cat $PID_FILE)
    if ps -p $PID > /dev/null; then
      echo "Application is running (PID: $PID)."
    else
      echo "PID file exists but application is not running."
    fi
  else
    echo "Application is not running."
  fi
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    restart
    ;;
  status)
    status
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status}"
esac

