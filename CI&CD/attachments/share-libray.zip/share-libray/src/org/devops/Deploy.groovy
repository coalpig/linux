package org.devops

def AnsibleDeploy(){
	sh """
	    ansible ${deployHost} -m file -a "path=/opt/app state=directory"
	    ansible ${deployHost} -m copy -a "src=${env.JAR_NAME} dest=/opt/app/"
        ansible ${deployHost} -m copy -a "src=kaoshi-service.sh dest=/opt/app/"
        ansible ${deployHost} -m shell -a "/bin/bash /opt/app/kaoshi-service.sh stop"
        ansible ${deployHost} -m shell -a "/bin/bash /opt/app/kaoshi-service.sh start ${env.VERSION}"
	"""
}