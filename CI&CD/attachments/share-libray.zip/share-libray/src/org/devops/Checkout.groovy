package org.devops

def CheckoutByTag(){
    checkout([$class: 'GitSCM',
                 branches: [[name: "${params.appVersion}"]],
                 userRemoteConfigs: [[url: '${env.GIT_URL}']]])	
}