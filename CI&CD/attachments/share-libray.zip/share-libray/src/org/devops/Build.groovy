package org.devops

def Build(){
	sh "/opt/maven/bin/mvn -s settings.xml clean package"
}