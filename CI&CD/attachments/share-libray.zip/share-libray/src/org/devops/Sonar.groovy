package org.devops

def SonarScanner(){
	withCredentials([string(credentialsId: 'sonar-token', variable: 'sonarToken')]) {
		sh """
			/opt/sonar-scanner/bin/sonar-scanner -Dsonar.host.url=${SONAR_URL} \
			-Dsonar.login=${sonarToken} \
			-Dsonar.projectKey=${JOB_NAME} \
			-Dsonar.projectName=${JOB_NAME} \
			-Dsonar.projectVersion=${appVersion} \
			-Dsonar.ws.timeout=30 \
			-Dsonar.projectDescription="luffy ${JOB_NAME}" \
			-Dsonar.links.homepage=${SONAR_URL}/${JOB_NAME} \
			-Dsonar.sources=src \
			-Dsonar.sourceEncoding=UTF-8 \
			-Dsonar.java.binaries=target/classes \
			-Dsonar.java.test.binaries=target/test-classes \
			-Dsonar.java.surefire.report=target/surefire-reports
		"""
	}
}