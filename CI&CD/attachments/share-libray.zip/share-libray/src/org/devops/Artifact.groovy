package org.devops

def CheckNexusArtifact(){
    POM = readMavenPom file: 'pom.xml'
    env.ARTIFACT_ID = "${POM.artifactId}"
    env.PACKAGING = "${POM.packaging}"
    env.GROUP_ID = "${POM.groupId}"
    env.GROUP_ID_URL = "${POM.groupId}".replace('.', '/')
    env.VERSION = "${POM.version}"
    env.JAR_FILE = "${env.ARTIFACT_ID}-${env.VERSION}.${env.PACKAGING}"
    
    // 构建 Nexus REST API 的 URL
    def artifactUrl = "${env.NEXUS_URL}/repository/${env.REPO_NAME}/${env.GROUP_ID_URL}/${env.ARTIFACT_ID}/${env.VERSION}/${env.JAR_FILE}"                    
    env.JAR_URL = "${artifactUrl}"
	
    // 发送 HTTP 请求到 Nexus
    def status = sh(script: "curl -s -o /dev/null -w '%{http_code}' -u ${env.NEXUS_USER} -I ${artifactUrl}", returnStdout: true).trim()
	env.JAR_STATUS = "${status}"
}


def UploadNexusArtifact(){
	sh """
		/opt/maven/bin/mvn -s settings.xml deploy:deploy-file \
		-DgroupId=${env.GROUP_ID} \
		-DartifactId=${env.ARTIFACT_ID} \
		-Dversion=${env.VERSION} \
		-Dpackaging=${env.PACKAGING} \
		-Dfile=target/${env.ARTIFACT_ID}-${env.VERSION}.${env.PACKAGING} \
		-Durl=${NEXUS_URL}/repository/${RELEASE_NAME}/ \
		-DrepositoryId=releases
	"""
}

def DownloadNexusArtifact(){
	sh "curl -s -u ${NEXUS_USER} -o ${env.JAR_NAME} ${env.JAR_URL}"
}