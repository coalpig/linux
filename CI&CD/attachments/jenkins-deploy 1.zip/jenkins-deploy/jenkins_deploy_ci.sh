#!/bin/bash

# 1.构建镜像
export JAVA_HOME=/opt/jdk8
/opt/maven/bin/mvn -s settings.xml clean package

# 2.代码扫描
if [ "$sonarSkip" == "false" ];then
  /opt/sonar-scanner/bin/sonar-scanner -Dsonar.host.url=http://10.0.0.203:9000 \
  -Dsonar.projectKey=kaoshi-maven-service \
  -Dsonar.projectName=kaoshi-maven-service \
  -Dsonar.projectVersion=${releaseVersion} \
  -Dsonar.token=${sonarToken} \
  -Dsonar.ws.timeout=30 \
  -Dsonar.projectDescription="my first project" \
  -Dsonar.links.homepage=http://10.0.0.203/devops/kaoshi-maven-service \
  -Dsonar.sources=src \
  -Dsonar.sourceEncoding=UTF-8 \
  -Dsonar.java.binaries=target/classes \
  -Dsonar.java.test.binaries=target/test-classes \
  -Dsonar.java.surefire.report=target/surefire-reports
fi

# 3.制品上传
if [ -f "target/xzs-${releaseVersion}.jar" ];then
  /opt/maven/bin/mvn -s settings.xml deploy:deploy-file \
  -DgroupId=com.mindskip \
  -DartifactId=xzs \
  -Dversion=${releaseVersion} \
  -Dpackaging=jar \
  -Dfile=target/xzs-${releaseVersion}.jar \
  -Durl=http://10.0.0.202:8081/repository/kaoshi-release/ \
  -DrepositoryId=releases
fi
