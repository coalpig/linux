#!/bin/bash

#1.下载制品
curl -s -u admin:admin -o /opt/deploy/xzs-${releaseVersion}.jar ${nexusUrl}

#2.替换系统变量
if [ -f "xzs-${releaseVersion}.jar" ];then
  sed -i "/APP_VERSION=/c APP_VERSION=$releaseVersion" kaoshi.env
  sed -i "/APP_ENV=/c APP_ENV=${deployEnv,,}" kaoshi.env
fi 

#3.调用Ansible剧本
ansible-playbook -l $deployHosts /opt/deploy/ansible_deploy_cd.yaml -e "app_version=$releaseVersion"
