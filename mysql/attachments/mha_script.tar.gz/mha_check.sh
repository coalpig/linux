#!/bin/bash

choice=$1
stop="masterha_stop  --conf=/etc/mha/app1.cnf"
status="masterha_check_status --conf=/etc/mha/app1.cnf"
repl="masterha_check_repl --conf=/etc/mha/app1.cnf"
conf_file="/etc/mha/app1.cnf"
log_file="/var/log/mha/app1/manager.log"


case "$choice" in 
  stop)
    $stop
    ;;
  start)
    nohup masterha_manager --conf=$conf_file --remove_dead_master_conf --ignore_last_failover  < /dev/null> $log_file 2>&1 &
    echo "it is start !"
    ;;
  restart)
    $stop 
    sleep 1
    nohup masterha_manager --conf=$conf_file --remove_dead_master_conf --ignore_last_failover  < /dev/null> $log_file 2>&1 &
    echo "it is start !"
    ;;
  status)
    $status
    ;;
  repl)
    $repl
    ;;
    *)
      echo "Usages: $0  {start|stop|restart|status|repl}"
      exit 1
esac
